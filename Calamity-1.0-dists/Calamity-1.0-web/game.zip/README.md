[![Athena Award Badge](https://img.shields.io/endpoint?url=https%3A%2F%2Faward.athena.hackclub.com%2Fapi%2Fbadge)](https://award.athena.hackclub.com?utm_source=readme)

Trapped in the depths of his own mind, unable - no, unwilling to set himself free. Calm your friend or watch as your worlds crash down.

Calamity - a visual novel written in Renpy in a day. Made for Storyboard.

I struggled with picking up the basics of Renpy again as I'd forgotten pretty much everything, but I did eventually re-learn them.
